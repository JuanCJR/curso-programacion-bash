#!/bin/bash
#Programa para revisar la declaracion de variables

opcion=0
nombre=Juan

echo "Opcion: $opcion y Nombre: $nombre"

