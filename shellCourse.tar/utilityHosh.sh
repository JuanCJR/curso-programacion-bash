#!/bin/bash
#Programa para inicializar variables e imprimir sus valores

option=1
result=Resultado

optionArgument=$1
resultArgument=$2

echo "Opcion: $option - Resultado:$resul
echo "Argumento 1: $optionArgument - Argumento 2: $resultArgument
