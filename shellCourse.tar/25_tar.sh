#!/bin/bash
#Programa para ejemplificar el empaquetamiento con el comando tar
#Autor: Juan C. Jimenez

echo "Empaquetar todos los scripts de la carpeta del curso"
tar -cvf shellCourse.tar *.sh


