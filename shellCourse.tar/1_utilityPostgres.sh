#!/bin/bash
#Programa para realizar algunas operaciones utilitarios de postgres
echo "Hola bienvenido al curso de programacion bash" 
